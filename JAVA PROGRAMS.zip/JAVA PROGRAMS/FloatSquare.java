import java.util.*;
public class FloatSquare 
{  
  
    public static void main(String[] args) 
{  
          
        float num1=5.5;  
        float num2=6.3;  
        System.out.println("num1 is : "+num1);  
        System.out.println("num2 is : "+num2);  
    }     
}  